"""Guard against promoting truncated, restarted or differently timed play scores."""
import copy
import unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch

from nav.marble_dynamics.full_round_benchmark import EXPECTED_SETTINGS, checked_rounds
from nav.marble_dynamics.reliability_eval import ContinuousController,await_full_round_context,continuous_branches
from nav.protocol import RAW_DIM,RAW_SCORE,NOOP_ACTION
import numpy as np
from nav.marble_dynamics.search import PlanMemory
from nav.marble_dynamics.reliability_viewer import round_trace_evidence


class FullRoundScores(unittest.TestCase):
    def data(self):
        return dict(evaluation_settings=copy.deepcopy(EXPECTED_SETTINGS), rounds=[
            dict(completed=True, engine_points=128.0, points=128.0,
                 initial_score=0.0, round_seconds=300.0, start_time_left_s=300.0,
                 played_seconds=299.968, falls=5, rescues=2)])

    def test_complete_round_keeps_falls_and_rescues(self):
        row = checked_rounds(self.data(), 1)[0]
        self.assertEqual((row['engine_points'], row['falls'], row['rescues']), (128, 5, 2))

    def test_replay_simulation_clock_need_not_equal_hunt_countdown(self):
        data = self.data()
        data['rounds'][0].update(round_seconds=180.0, start_time_left_s=180.0,
            played_seconds=184.321)
        self.assertEqual(checked_rounds(data, 1)[0]['played_seconds'], 184.321)

    def test_partial_restart_or_late_start_cannot_be_a_score(self):
        for field, value in [('completed', False), ('played_seconds', 19.2),
                             ('start_time_left_s', 250.0), ('initial_score', 3.0)]:
            data = self.data()
            data['rounds'][0][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                checked_rounds(data, 1)

    def test_native_score_missing_disagreeing_or_nonfinite_is_rejected(self):
        for value in (None, float('nan'), 127.0):
            data = self.data()
            data['rounds'][0]['engine_points'] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                checked_rounds(data, 1)

    def test_missing_round_or_changed_cadence_rescue_is_rejected(self):
        with self.assertRaises(ValueError):
            checked_rounds(self.data(), 2)
        for key, value in [('decision_ms', 16), ('rescue_s', 0.0), ('oob_click', False)]:
            data = self.data()
            data['evaluation_settings'][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                checked_rounds(data, 1)


class FullRoundStartup(unittest.TestCase):
    def env(self,contexts):
        obs=np.zeros(RAW_DIM,np.float32)
        env=SimpleNamespace(info={'round_ms':300000},round_ended=False,reconnected=False,
            msg=SimpleNamespace(obs=obs,dynamics=contexts[0]),time_left_s=Mock(return_value=300.))
        pending=iter(contexts[1:])
        def advance(action,repeat):
            self.assertEqual(action,NOOP_ACTION);self.assertEqual(repeat,1)
            env.msg=SimpleNamespace(obs=obs,dynamics=next(pending))
            return env.msg,dict(round_ended=False,reconnected=False)
        env.step=Mock(side_effect=advance)
        return env

    def ready(self):
        return {'native':{'state':{}},'game_context':{'available':True}}

    def test_missing_startup_snapshots_wait_neutrally_until_audited_payload(self):
        env=self.env([None,{},dict(native={'state':{}},game_context={'available':False}),self.ready()])
        self.assertEqual(await_full_round_context(env),3)
        self.assertEqual(env.step.call_count,3)
        self.assertIsNotNone(env.msg.dynamics)

    def test_ready_context_starts_without_extra_game_time(self):
        env=self.env([self.ready()])
        self.assertEqual(await_full_round_context(env),0)
        env.step.assert_not_called()

    def test_missing_context_cannot_become_an_unbounded_wait(self):
        env=self.env([None]*4)
        with self.assertRaisesRegex(RuntimeError,'bounded neutral setup'):
            await_full_round_context(env,max_wait=3)
        self.assertEqual(env.step.call_count,3)

    def test_late_nonzero_or_changed_round_refuses_scored_start(self):
        for kind in ('late','scored','ended','reconnected'):
            env=self.env([self.ready()])
            if kind=='late':env.time_left_s.return_value=299.
            elif kind=='scored':env.msg.obs[RAW_SCORE]=1.
            else:setattr(env,'round_ended' if kind=='ended' else 'reconnected',True)
            with self.subTest(kind=kind),self.assertRaises(RuntimeError):
                await_full_round_context(env)
            env.step.assert_not_called()

    def test_round_end_during_setup_is_rejected(self):
        env=self.env([None,self.ready()])
        env.step.side_effect=None
        env.step.return_value=(env.msg,dict(round_ended=True,reconnected=False))
        with self.assertRaisesRegex(RuntimeError,'Native round changed'):
            await_full_round_context(env)
        self.assertEqual(env.step.call_count,1)


class ContinuousEvents(unittest.TestCase):
    def controller(self):
        controller=ContinuousController.__new__(ContinuousController)
        controller.memory=PlanMemory()
        controller.memory.actions=[[0]*9]*8;controller.memory.gem=[1,2,3]
        controller.current=[1,2,3];controller.resource={'id':42}
        controller.commit_left=4;controller.cooldown=32
        controller.last_prediction={'position':[1,2,3]};controller.last_action=[1]*9
        controller.route=Mock();controller.terrain=object()
        controller.nav=Mock();controller.nav.model=object()
        from collections import Counter
        controller.counts=Counter()
        return controller

    def test_no_live_gem_returns_complete_neutral_bridge_reply(self):
        controller=self.controller();controller.kind='frozen_navigator';controller.fields={}
        msg=SimpleNamespace(obs=None,dynamics={'native':{'state':{'mode':0,'oob':False}}})
        with patch('nav.marble_dynamics.reliability_eval.tour',return_value=(None,None,[])):
            action,info=controller.action(msg,100)
        self.assertEqual(len(action),9)
        self.assertEqual((action[4],action[6],action[8]),(0,0,0))
        self.assertEqual(info['label'],'neutral')

    def test_fall_or_end_cancels_old_commands_without_reading_next_round_state(self):
        for event in ('fell','round_ended','reconnected'):
            controller=self.controller()
            outcome=dict(fell=False,round_ended=False,reconnected=False,gem_delta=0)
            outcome[event]=True
            # End/reconnect observations need not carry the previous native state.
            with self.subTest(event=event), patch('nav.marble_dynamics.reliability_eval.FrozenNavigator') as reset:
                controller.observe(None,SimpleNamespace(dynamics=None),outcome)
                self.assertFalse(controller.memory.remaining)
                self.assertIsNone(controller.current)
                self.assertIsNone(controller.resource)
                self.assertIsNone(controller.last_action)
                self.assertIsNone(controller.last_prediction)
                self.assertEqual(controller.cooldown,0)
                reset.assert_called_once()

    def test_real_pickup_retains_landing_even_after_selected_gem_disappears(self):
        controller=self.controller();controller.last_prediction=None
        controller.memory.landing_goal=[4,5,6];controller.memory.goal_item_id=42
        controller.memory.landing_after_reply=2
        msg=SimpleNamespace(obs=None,dynamics={'native':{'state':{}},'items':[{'id':99}]})
        controller.observe(None,msg,dict(fell=False,round_ended=False,reconnected=False,gem_delta=5))
        self.assertTrue(controller.memory.landing_mode)
        self.assertEqual(controller.memory.landing_goal,[4,5,6])
        self.assertEqual(controller.memory.executed,1)
        self.assertEqual(controller.counts['post_pickup_landing'],1)

    def test_native_respawn_cancels_actor_and_plan_when_oob_flag_was_missed(self):
        controller=self.controller();controller.observed_respawns=10
        msg=SimpleNamespace(dynamics={'game_context':{'available':True,'respawns':11}})
        with patch('nav.marble_dynamics.reliability_eval.FrozenNavigator') as reset:
            controller.observe(None,msg,dict(fell=False,round_ended=False,reconnected=False,gem_delta=0))
        self.assertFalse(controller.memory.remaining)
        self.assertIsNone(controller.observed_respawns)
        self.assertIsNone(controller.last_action)
        self.assertEqual(controller.counts['cancel:observed_native_respawn'],1)
        reset.assert_called_once()


class GeometryComponent(unittest.TestCase):
    def test_declared_order_contains_all_branches_and_balances_first(self):
        args=SimpleNamespace(geometry_reference=True)
        orders=[continuous_branches(args,i,681013) for i in range(3)]
        expected={'physics_plan','geometry_navigator','frozen_navigator'}
        self.assertEqual({order[0] for order in orders},expected)
        for order in orders:self.assertEqual(set(order),expected)
        self.assertEqual(continuous_branches(SimpleNamespace(),0,681013),('physics_plan','frozen_navigator'))

    def test_geometry_route_changes_routing_without_changing_actor_terrain(self):
        terrain=object();geometry=object();engine=SimpleNamespace()
        args=SimpleNamespace(geometry_route=True,geometry_terrain=geometry,navigator_first=True)
        with patch('nav.marble_dynamics.reliability_eval.FrozenNavigator') as actor,patch('nav.marble_dynamics.reliability_eval.RoutePlanner') as route:
            ContinuousController(terrain,engine,'protected.pth',args,'geometry_navigator')
            actor.assert_called_once_with(terrain,'protected.pth')
            route.assert_called_once_with(geometry)

    def test_geometry_actor_never_searches_and_logs_before_destination(self):
        controller=ContinuousEvents().controller();controller.kind='geometry_navigator'
        controller.args=SimpleNamespace(global_goals=True);controller.fields={}
        controller._search=Mock(side_effect=AssertionError('Routing-only branch invoked physical search'))
        goal=(7.,8.,9.,2.,12.);waypoint=[3.,4.,5.]
        controller.route.navigate.return_value=(waypoint,False)
        action=[.2,0,0,0,0,0,0,0,0];controller.nav.act.return_value=action
        msg=SimpleNamespace(obs=np.zeros(RAW_DIM),dynamics={'native':{'state':{'mode':0,'oob':False,'position':[0,0,0]}},
            'items':[{'id':41,'gem':True,'position':[7.,8.,9.]}]})
        with patch('nav.marble_dynamics.reliability_eval.tour',return_value=(goal,None,[goal])),patch('nav.marble_dynamics.reliability_eval.observed_gems',return_value=[goal]):
            sent,info=controller.action(msg,100)
        controller._search.assert_not_called()
        self.assertEqual(sent,action);self.assertIsNone(controller.last_prediction)
        self.assertEqual(info['label'],'geometry_navigator')
        self.assertEqual(info['goal_context']['destination'],[7.,8.,9.])
        self.assertEqual(info['goal_context']['waypoint'],waypoint)
        self.assertEqual(info['goal_context']['item_id'],41)
        self.assertEqual(info['actor_action'],action)
        self.assertEqual(controller.counts['planner_decisions'],0)


class FullRoundReview(unittest.TestCase):
    def row(self,clock,respawns=0,position=None):
        return dict(before={'native':{'frame_clock_ms':clock,'object_id':1,'state':{'position':position or [0,0,0]}},
            'game_context':{'available':True,'respawns':respawns},
            'items':[{'id':42,'gem':True,'position':[10,20,30]}]},
            choice={'label':'A2_fallback'},predicted=None,
            outcome={'fell':False,'round_ended':False,'reconnected':False})

    def test_respawn_and_control_gaps_break_line_without_deleting_measured_point(self):
        logs=[self.row(100),self.row(164,1,[50,0,0]),self.row(292,1,[51,0,0])]
        original=copy.deepcopy(logs)
        gaps,reasons,_,_=round_trace_evidence(logs)
        self.assertEqual(gaps,[False,True,True])
        self.assertIn('native_respawn',reasons[1]);self.assertIn('unobserved_control_interval',reasons[2])
        self.assertEqual(logs,original)

    def test_checked_item_comes_from_same_before_and_fallback_goal_stays_unknown(self):
        a=self.row(100);a['choice']['goal_item_id']=42;a['predicted']={}
        b=self.row(164);b['choice']['goal_item_id']=42
        c=self.row(228);c['choice']['goal_item_id']=99;c['predicted']={}
        c['before']['items']=[{'id':42,'gem':True,'position':[999,999,999]}]
        _,_,goals,kinds=round_trace_evidence([a,b,c])
        self.assertEqual(goals,[[10,20,30],[None,None,None],[None,None,None]])
        self.assertEqual(kinds,['checked_observed_gem','unknown','unknown'])

    def test_explicit_destination_is_preserved_instead_of_item_or_waypoint(self):
        row=self.row(100);row['choice']['goal_context']=dict(destination=[10.001,20,30],waypoint=[3,4,5],kind='gem')
        _,_,goals,kinds=round_trace_evidence([row])
        self.assertEqual(goals,[[10.001,20,30]]);self.assertEqual(kinds,['gem'])


if __name__ == '__main__':
    unittest.main()
